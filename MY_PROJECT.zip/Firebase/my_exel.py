from openpyxl import load_workbook
from openpyxl_image_loader import SheetImageLoader
import shutil
import os
import io


def extract_images_from_excel(file_path, output_folder='extracted_images'):
    """
        Extract images from an Excel file and save them as WebP files with a transparent background and under 75KB.

        Parameters:
        - file_path (str): The path to the Excel file.
        - output_folder (str, optional): The folder to save the extracted images. Default is 'extracted_images'.

        Returns:
        - List: A list of image information, where each element is a sublist containing the image name and PIL Image object.
        """
    image_list = []

    # Create the output folder if it doesn't exist
    os.makedirs(output_folder, exist_ok=True)

    try:
        # Load the Excel workbook
        workbook = load_workbook(file_path)

        # Iterate through each sheet in the workbook
        for sheet_name in workbook.sheetnames:
            sheet = workbook[sheet_name]

            # Create an image loader for the sheet
            image_loader = SheetImageLoader(sheet)

            # Initialize index for image names
            image_index = 1

            # Iterate through images in the sheet
            for cell in image_loader._images:
                # Get the image from the cell
                image = image_loader.get(cell)

                # Ensure transparency is preserved by converting to RGBA if needed
                if image.mode != 'RGBA':
                    image = image.convert('RGBA')

                # Save image as WebP with a transparent background
                image_name = f'image{image_index}.webp'
                path = os.path.join(output_folder, image_name)
                resize_and_save_webp(image, path)

                # Append image information to the list
                image_list.append(image_name)

                # Increment the image index
                image_index += 1
    except OSError as e:
        # Handle the case where an error occurs (e.g., file not exist)
        print(f"Error: {e}")

    # Return the list of image information
    return image_list


def resize_and_save_webp(image, output_path, target_size_kb=75):
    """
    Resize an image to be less than target size kb and save it as a WebP file with transparent background.

    Parameters:
    - image (PIL.Image.Image): The input image.
    - output_path (str): The path to save the resized image as a WebP file.
    - target_size_kb (int, optional): The target size in kilobytes. Default is 75.
    """

    max_size = target_size_kb * 1024
    min_width, min_height = 50, 50  # Set minimum width and height as needed

    while True:
        buffer = io.BytesIO()

        # Save as PNG with transparency
        image.save(buffer, format="PNG")

        # Resize the image
        image = image.resize((image.width * 90 // 100, image.height * 90 // 100))

        # Check size after resizing
        size = buffer.tell()
        if size <= max_size or image.width <= min_width or image.height <= min_height:
            break

    # Convert the resized image to WebP format with transparency
    image.save(output_path, format="WEBP", lossless=True, method=6, quality=75, alpha_filter=True)

def delete_folder(folder_path):
    """
    Delete a folder and its contents.

    Parameters:
    - folder_path (str): The path to the folder to be deleted.
    """
    try:
        # Attempt to remove the folder and its contents
        shutil.rmtree(folder_path)
        print(f"Folder '{folder_path}' and its contents removed successfully.")
    except OSError as e:
        # Handle the case where an error occurs (e.g., folder not empty)
        print(f"Error: {e}")