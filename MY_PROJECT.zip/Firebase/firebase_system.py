import pyrebase


# this config is _my firebase_ reference so if you prefer to upload to your firebase - just load here the details!!
# also - make sure your firebase rules are matches to what you aloud!!!
config = {
    "apiKey": "AIzaSyBlLBOfRc1lLsF7f7EWfS3Aa20adVsxZ1g",
    "authDomain": "exel-formater.firebaseapp.com",
    "projectId": "exel-formater",
    "storageBucket": "exel-formater.appspot.com",
    "messagingSenderId": "44685958660",
    "appId": "1:44685958660:web:c7fb2401ff100c27679f51",
    "measurementId": "G-2JSQ95G4CV",
    "databaseURL": "https://exel-formater-default-rtdb.europe-west1.firebasedatabase.app/"
}


def upload_images_to_firebase(image_list, storage,out_folder):
    """
    Upload a list of images to Firebase Storage.

    Parameters:
    - image_list (List): A list of image information, where each element is a sublist containing the image name
                        and PIL Image object.
    - storage: Firebase Storage instance for uploading images.
    - out_folder: the folder that storage the images before uploading
    """
    for image in image_list:
        # Define the path on Firebase Cloud Storage
        path_on_cloud = f"images/{image}"

        # Define the local path of the image file
        path_local = out_folder+"/" + image

        # Upload the image to Firebase Storage
        storage.child(path_on_cloud).put(path_local)