from Firebase import my_exel as ex
import Firebase.firebase_system as fb
import os

if __name__ == '__main__':
    # brings up first of all the firebase reference with his storage
    firebase = fb.pyrebase.initialize_app(fb.config)
    storage = firebase.storage()
    path_on_cloud = "images/"  # the name of the current img dot(.)webp

    first_time = True

    while True:
        if first_time is False:
            choice = input("Would you like to end the process? Y/N\n")
            while True:
                if choice.lower() != "y" and choice.lower() != "n":
                    choice = input("Would you like to end the process? Y/N\n")
                else:
                    break
            if choice.lower() == "y":
                break

        while True:
            if first_time is True:
                # write the name of your xlsx file you want to upload from it images
                xlsx_file_path = input("Hello, please insert the path of the xlsx file here"
                                       "\nor just its full name if its in this directory: ")  # i.e products.xlsx
                first_time = False
            else:
                # write the name of your xlsx file you want to upload from it images
                xlsx_file_path = input("Lets try it again, please insert the path of the xlsx file here"
                                       "\nor just its full name if its in this directory: ")  # i.e products.xlsx

            # in case of miss validation
            if xlsx_file_path[-5:len(xlsx_file_path)] != ".xlsx":
                xlsx_file_path += ".xlsx"

            # creating temp folder for upload the images
            out_folder = 'extracted_images'
            os.makedirs(out_folder, exist_ok=True)
            print("Temporary folder: 'extracted_images' has been created, please do not delete it :)")
            try:
                # creates a list of the images for to send them to the uploader function
                image_list = ex.extract_images_from_excel(xlsx_file_path, out_folder)

                # uploading in here the list of our images
                fb.upload_images_to_firebase(image_list, storage, out_folder)
                print("Images of "+xlsx_file_path+" uploaded successfully into firebase!")
                
                # deleting our temp folder
                ex.delete_folder(out_folder)

                break
            except Exception as e:
                # deleting our temp folder
                ex.delete_folder(out_folder)

                # Handle the case where an error occurs (e.g., file not exist)
                print(f"Error: {e}")
                print("Please enter a valid XLSX file name or path.\n")

    # end of process
    print("End of process, goodbye")